module VagrantPlugins
  module HostManager
    VERSION = '1.8.1'
  end
end
