module Vagrant
  module LXC
    VERSION = "1.2.1"
  end
end
