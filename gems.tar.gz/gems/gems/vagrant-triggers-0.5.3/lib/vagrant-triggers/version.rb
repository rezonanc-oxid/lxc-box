module VagrantPlugins
  module Triggers
    VERSION = "0.5.3"
  end
end
